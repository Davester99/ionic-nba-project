export class Team {
    constructor(
        public id: string,
        public name: string,
        public location: string,
        public image: string,
        public division: string
    ) {}
}